""" This script is starting the game. """


from src.console_chess_imandyr.game import Menu


if __name__ == "__main__":
    while True:
        Menu.start()
